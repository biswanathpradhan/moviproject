-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 26, 2020 at 02:33 AM
-- Server version: 5.6.47-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `i6533905_mg1`
--

-- --------------------------------------------------------

--
-- Table structure for table `aa_payment`
--

CREATE TABLE `aa_payment` (
  `id` int(11) NOT NULL,
  `item_number` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `payment_amount` double(10,2) NOT NULL,
  `payment_currency` varchar(255) NOT NULL,
  `txn_id` varchar(255) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aa_payment`
--

INSERT INTO `aa_payment` (`id`, `item_number`, `item_name`, `payment_status`, `payment_amount`, `payment_currency`, `txn_id`, `create_at`) VALUES
(1, 'T00212', 'Test', 'success', 120.00, 'INR', 'TIX0001', '2020-07-26 07:06:50');

-- --------------------------------------------------------

--
-- Table structure for table `aa_product`
--

CREATE TABLE `aa_product` (
  `pid` int(11) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `price` bigint(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `pcode` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aa_product`
--

INSERT INTO `aa_product` (`pid`, `pname`, `price`, `image`, `content`, `pcode`) VALUES
(3, 'test', 120, '1595748151coax_plug_1.jpg', 'xsxsxss', 't002123'),
(2, 'test', 120, '1595748151coax_plug_1.jpg', 'xsxsxss', 't00212'),
(4, 'test', 120, '1595748151coax_plug_1.jpg', 'xsxsxss', 't00214'),
(5, 'test', 120, '1595748151coax_plug_1.jpg', 'xsxsxss', 't00215');

-- --------------------------------------------------------

--
-- Table structure for table `aa_user`
--

CREATE TABLE `aa_user` (
  `id` int(11) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aa_user`
--

INSERT INTO `aa_user` (`id`, `uname`, `pass`, `status`, `date`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 1, '2020-07-25 06:55:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aa_payment`
--
ALTER TABLE `aa_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aa_product`
--
ALTER TABLE `aa_product`
  ADD PRIMARY KEY (`pid`),
  ADD UNIQUE KEY `pcode` (`pcode`);

--
-- Indexes for table `aa_user`
--
ALTER TABLE `aa_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aa_payment`
--
ALTER TABLE `aa_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `aa_product`
--
ALTER TABLE `aa_product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `aa_user`
--
ALTER TABLE `aa_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
