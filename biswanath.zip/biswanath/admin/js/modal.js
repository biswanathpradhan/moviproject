
/////////////// 1st Script  ////////////////

   $(".method-opt").click(function(){
            var method = $(this).data('method');
                            if(method != 'template')
                {
                    $("#hid-method").val(method);
                    $("#modalProdDetail").hide();
                    $("#modalProdOption").show();
                }
                    });
                $(".makenow").click(function(){
            $("#modalPick").hide();
            $("#modalProdDetail").show();
            $("input[name=package]").val($(this).data('package'));
        });
                $(".backtomethod").click(function(){
            $(".bc-opt-1").hide();
            $("#modalProdDetail").show();
        });
        $('.closeModal').click(function(){
            $('#modalProdDetail').hide();
            $(".modal-option").hide();
        });
        $( function(){
            if (window.matchMedia('(max-width: 480px)').matches) {
                $( document ).trigger( "enhance.tablesaw" );
                $('.print-image, .print-desc, .person-img-wrapper').removeClass('col-xs-6').addClass('col-xs-12');
            }
            else{
                $('.print-image, .print-desc, .person-img-wrapper').removeClass('col-xs-12').addClass('col-xs-6');
            }

            $(window).resize(function(){
                if ( $(window).width() < 480 ){
                    $( document ).trigger( "enhance.tablesaw" );
                    $('.print-image, .print-desc, .person-img-wrapper').removeClass('col-xs-6').addClass('col-xs-12');
                }
                else{
                    $('.print-image, .print-desc, .person-img-wrapper').removeClass('col-xs-12').addClass('col-xs-6');
                }
            });


            //$( document ).trigger( "enhance.tablesaw" );
        });
        localStorage.setItem('wetransfer', '');
        localStorage.setItem('dropbox', '');
        localStorage.setItem('gdrive', '');
		
		
		
		
/////////////// 1st Script  ////////////////		
		
		

/////////////// 2nd Script  ////////////////
		
		  $(".side-opt").click(function(){
    $("input[name=sides]").val($(this).data('side'));
    $(".bc-opt-1").hide();
    $(".bc-opt-2").show();
  });
  $(".orient-opt").click(function(){
    $("input[name=layout_id]").val($(this).data('orient'));
    $("#prodform").submit();
  });
  $(".backstep1").click(function(){
    $(".bc-opt-2").hide();
    $(".bc-opt-1").show();
  })
  

/////////////// 2nd Script  ////////////////




/////////////// 1st Script  ////////////////

   $(".method-opt").click(function(){
            var method = $(this).data('method');
                            if(method != 'template')
                {
                    $("#hid-method").val(method);
                    $("#modalProdDetail").hide();
                    $("#modalProdOption").show();
                }
                    });
                $(".makenow2").click(function(){
            $("#modalPick").hide();
            $("#modalProdDetail").show();
            $("input[name=package]").val($(this).data('package'));
        });
                $(".backtomethod").click(function(){
            $(".bc-opt-1").hide();
            $("#modalProdDetail").show();
        });
        $('.closeModal').click(function(){
            $('#modalProdDetail').hide();
            $(".modal-option").hide();
        });
        $( function(){
            if (window.matchMedia('(max-width: 480px)').matches) {
                $( document ).trigger( "enhance.tablesaw" );
                $('.print-image, .print-desc, .person-img-wrapper').removeClass('col-xs-6').addClass('col-xs-12');
            }
            else{
                $('.print-image, .print-desc, .person-img-wrapper').removeClass('col-xs-12').addClass('col-xs-6');
            }

            $(window).resize(function(){
                if ( $(window).width() < 480 ){
                    $( document ).trigger( "enhance.tablesaw" );
                    $('.print-image, .print-desc, .person-img-wrapper').removeClass('col-xs-6').addClass('col-xs-12');
                }
                else{
                    $('.print-image, .print-desc, .person-img-wrapper').removeClass('col-xs-12').addClass('col-xs-6');
                }
            });


            //$( document ).trigger( "enhance.tablesaw" );
        });
        localStorage.setItem('wetransfer', '');
        localStorage.setItem('dropbox', '');
        localStorage.setItem('gdrive', '');
		
		
		
		
/////////////// 1st Script  ////////////////		
		
		

/////////////// 2nd Script  ////////////////
		
		  $(".side-opt").click(function(){
    $("input[name=sides]").val($(this).data('side'));
    $(".bc-opt-1").hide();
    $(".bc-opt-2").show();
  });
  $(".orient-opt").click(function(){
    $("input[name=layout_id]").val($(this).data('orient'));
    $("#prodform").submit();
  });
  $(".backstep1").click(function(){
    $(".bc-opt-2").hide();
    $(".bc-opt-1").show();
  })
  

/////////////// 2nd Script  ////////////////

