<?php

 $ob=new adminmain();

if(isset($_POST['login'])){   
    $res=$ob->login($con,$_POST);
    if(count($res)>0){

    	$_SESSION['uid']=1;   	

    	echo '<script>location.href="dashboard.php";</script>';
    }else{
      echo '<script>alert("invalid login etails");
 location.href="index.php";</script>';
    }
}

 $list=$ob->plist($con);

 $pay=$ob->paylist($con);


 if(isset($_POST['postproduct'])){  

	$_POST['img']='';

 	if(isset($_FILES['img']['name'])){
 		$target_dir = "upload/";
 		$fname=basename(time().$_FILES["img"]["name"]);
		$target_file = $target_dir . $fname;
 		 if (move_uploaded_file($_FILES["img"]["tmp_name"], $target_file)) {
		   $_POST['img']=$fname;
		  } else {
		   $_POST['img']='';
		  }

 	}

    $res=$ob->addproduct($con,$_POST);
    if($res>0){
    	echo '<script>alert("Added sucessfully"); location.href="list.php";</script>';
    }else{
      echo '<script>alert("unable to process");
 location.href="add.php";</script>';
    }
}

if(isset($_GET['id'])){   
	$k=$ob->edit_prod($con,$_GET['id']);
}	


if(isset($_GET['delt'])){   
	$k=$ob->removeprod($con,$_GET['delt']);
	echo '<script>alert("deleted sucessfully"); location.href="list.php";</script>';
}	




 if(isset($_POST['updateprod'])){ 	

 	if(isset($_FILES['img']['name'])){
 		$target_dir = "upload/";
 		$fname=basename(time().$_FILES["img"]["name"]);
		$target_file = $target_dir . $fname;
 		 if (move_uploaded_file($_FILES["img"]["tmp_name"], $target_file)) {
		   $_POST['img']=$fname;
		  } else {
		   $_POST['img']=$_POST['file'];
		  }

 	}else{
 		$_POST['img']=$_POST['file'];
 	}

    $res=$ob->updateproduct($con,$_POST);
    if($res>0){
    	echo '<script>alert("updated sucessfully"); location.href="list.php";</script>';
    }else{
      echo '<script>alert("unable to process");</script>';
    }
}


if(isset($_GET['prod'])){   
    $show=$ob->show_prod($con,$_GET['prod']);
}   




?>
