<?php

	$con=mysqli_connect("localhost","i6533905_mg1","bidya@123","i6533905_mg1");

	define('currency','INR');

?>



