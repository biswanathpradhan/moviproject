<?php

class adminmain{

 
  function login($con,$data){   
    $res=mysqli_query($con,"select * from aa_user where uname='".$data['name']."' and pass='".md5($data['password'])."'");
    $result=mysqli_fetch_array($res);    
    return  $result;

  }


   function plist($con){   
    $res=mysqli_query($con,"select * from aa_product");
    while($row=mysqli_fetch_array($res)){
      $result[]=$row;
    }    
    return  $result;

  }



   function paylist($con){   
    $res=mysqli_query($con,"select * from aa_payment");
    while($row=mysqli_fetch_array($res)){
      $result[]=$row;
    }    
    return  $result;

  }


    function getpayment($con,$id){   
    $res=mysqli_query($con,"select * from aa_payment where id='".$id."'");
    $row=mysqli_fetch_array($res);
     
    return  $row;

  }


   function addproduct($con,$data){   
    $sql="insert into aa_product set
      pname='".$data['name']."',
      price='".$data['price']."',
      image='".$data['img']."',
      content='".$data['description']."',
      pcode='".$data['sku']."'";

    
    $res=mysqli_query($con,$sql);
    $result=mysqli_insert_id($con);    
    return  $result;

  }


  function edit_prod($con,$id){   
    $res=mysqli_query($con,"select * from aa_product where pid='".$id."'");
    $row=mysqli_fetch_array($res);
     
    return  $row;

  }

    function removeprod($con,$id){   
    $res=mysqli_query($con,"delete from aa_product where pid='".$id."'");
    $row=mysqli_fetch_array($res);
     
    return  1;

  }


  function updateproduct($con,$data){   
    $sql="update aa_product set
      pname='".$data['name']."',
      price='".$data['price']."',
      image='".$data['img']."',
      content='".$data['description']."',
      pcode='".$data['sku']."' where pid='".$data['id']."'";
    
    $res=mysqli_query($con,$sql);
        
    return  1;

  }


  function show_prod($con,$id){   
    $res=mysqli_query($con,"select * from aa_product where pcode='".$id."'");
    $row=mysqli_fetch_array($res);
     
    return  $row;

  }


  function serach_result($con,$q){   
    $res=mysqli_query($con,"select * from aa_product where pname like '%".$q."%' or pcode like '%".$q."%'");
    while($row=mysqli_fetch_array($res)){
      $result[]=$row;
    }    
    return  $result;

  }


  function paginationlist($con,$strt,$limit){   
    $res=mysqli_query($con,"select * from aa_product LIMIT $strt, $limit");
    while($row=mysqli_fetch_array($res)){
      $result[]=$row;
    }    
    return  $result;

  }

  function pagenumb($con,$limit,$page_no){  
      $rs_result=mysqli_query($con,"SELECT COUNT(*) As total_records FROM `aa_product`");  
      $row = mysqli_fetch_row($rs_result);     

      $total_records = $row[0];
      
      $total_no_of_pages = ceil($total_records / $limit);
      $second_last = $total_no_of_pages - 1;

       if($page_no > 1){
        echo "<li><a href='index.php?page_no=1'>First Page</a></li>";
        } ?>      

        <?php 
        if($total_no_of_pages>1){
          for ($counter = 1; $counter <= $total_no_of_pages; $counter++){
                  if ($counter == $page_no) {
                    echo "<li class='active'><a>$counter</a></li>"; 
                  }else{
                    echo "<li><a href='?page_no=$counter'>$counter</a></li>";
                  }
                }
           }       
         
        if($page_no < $total_no_of_pages){
        echo "<li><a href='index.php?page_no=$total_no_of_pages'>Last &rsaquo;&rsaquo;</a></li>";
        } 
  }



}