<?php 
  require_once('autoload.php');

  if($_SESSION['uid']!=1){
      echo '<script>location.href="index.php";</script>';
    }

    //echo "<pre>"; print_r($list); exit;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Admin Login</title>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/responsive-menu.js"></script>
<script src="js/slick.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/responsive-menu.css" />
<link rel="stylesheet" type="text/css" href="css/slick.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
</head>
<body>

<div class="dashboard clearfix">
<div class="fixheader clearfix">  
  <div class="dashboard-menubar clearfix">
    <div class="container clearfix">
      <div class="row clearfix">
        <div class="col-sm-12">
          <nav class="navbar navbar-inverse" role="navigation">
            <div class="container-fluid">           
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  <li><a href="list.php">Product Management</a></li>
                  <li><a href="pay.php">Payment Management</a></li>
                  <li><a href="logout.php" class=" ">logout</a></li>                
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
  </div>

    <div class="dashboard-main clearfix">
    <div class="container clearfix">
    <div class="row clearfix">
      <div class="col-sm-12">
       <div class="secondary-container clearfix">
  <div class="projects clearfix">
    <div class="container clearfix">
      <div class="row clearfix">  
        <div class="col-sm-12">   
        <a href="add.php" class="btn btn-primary">+ADD</a>      
          <div class="projects-tbl clearfix">
            <table id="table_id">
              <tr>
                <th width="10%">Image</th>
                <th width="10%">Name</th>                
                <th width="10%">SKU</th>
                <th width="15%">Price</th>
                <th width="10%">Action</th>
              </tr> 

              <?php foreach($list as $k){ ?>
              <tr>
                <th width="10%"><img src="upload/<?php echo $k['image']; ?>" width=100></th>
                <th width="10%"><?php echo $k['pname']; ?>/th>                
                <th width="10%"><?php echo $k['pcode']; ?></th>
                <th width="15%"><?php echo $k['price']; ?></th>
                <th width="10%"><a href="edit.php?id=<?php echo $k['pid']; ?>">Edit</a>|
                <a href="list.php?delt=<?php echo $k['pid']; ?>">Delete</a>
              </th>
              </tr>                   
              <?php } ?>                
                        
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
        
      </div>
    </div>
  </div>
  </div>
</div>
 
</div>
<script>
$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>

</body>
</html>
