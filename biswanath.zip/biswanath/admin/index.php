<?php require_once('autoload.php'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title>Admin Login</title>

<script type="text/javascript" src="js/jquery.min.js"></script>

<script type="text/javascript" src="js/bootstrap.min.js"></script>

<script type="text/javascript" src="js/responsive-menu.js"></script>

<script src="js/slick.js"></script>

<link rel="stylesheet" type="text/css" href="css/style.css" />

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />

<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />

<link rel="stylesheet" type="text/css" href="css/responsive-menu.css" />

<link rel="stylesheet" type="text/css" href="css/slick.css" />

</head>

<body>

<div class="user clearfix">

 

  <div class="container clearfix">

    <div class="user-caption">

     

        <div class="user-form">

          <h2>Welcome Back</h2>

            <form method="post">

            <input type="hidden" name="_token" id="_token" value="j9xR4DFH9TYa0LpqJWUzQYebhe7U4VvBhn5IsYQQ">

            <input type="text" name="name" placeholder="Username">

            <input type="password" name="password" placeholder="password" />

            

            <div class="clearfix"></div>

            <input type="submit" name="login" value="Log In" class="btn btn-primary" />

          </form>

        </div>

     

    </div>

  </div>

</div>

</body>

</html>

