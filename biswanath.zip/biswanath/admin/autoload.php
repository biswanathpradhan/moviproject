<?php
session_start();
require_once('class/db.php');
require_once('class/mclass.php');
require_once('class/post.php');

if(isset($_POST['transdata'])){   
   
   $k=$ob->show_prod($con,$_POST['id']);
    $htm='<div class="col-sm-6">
                <img src="upload/'.$k['image'].'" style="width: 350px;">
        </div>  
        <div class="col-sm-6">
             <h3>'.$k['pname'].'</h3> 
             <h5>'.$k['pcode'].'</h5>
             <h5>'.currency.$k['price'].'</h5>
        </div>';
   echo json_encode($htm);     
} 

?>