
<?php 
  require_once('autoload.php');

  if($_SESSION['uid']!=1){
      echo '<script>location.href="index.php";</script>';
    }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Admin Login</title>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/responsive-menu.js"></script>
<script src="js/slick.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/responsive-menu.css" />
<link rel="stylesheet" type="text/css" href="css/slick.css" />
</head>
<body>

<div class="dashboard clearfix">
<div class="fixheader clearfix">  
  <div class="dashboard-menubar clearfix">
    <div class="container clearfix">
      <div class="row clearfix">
        <div class="col-sm-12">
          <nav class="navbar navbar-inverse" role="navigation">
            <div class="container-fluid">           
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  <li><a href="list.php">Product Management</a></li>
                  <li><a href="pay.php">Payment Management</a></li>
                  <li><a href="logout.php" class=" ">logout</a></li>                
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
  </div>

    <div class="dashboard-main clearfix">
    <div class="container clearfix">
    <div class="row clearfix">
      <div class="col-sm-12">
       <div class="secondary-container clearfix">
  <div class="projects clearfix">
    <div class="container clearfix">
      <div class="row clearfix">  
        <div class="col-sm-12">   
     \
          <div class="projects-tbl clearfix">
                    
<form method="post"  enctype="multipart/form-data">
     
<div class="secondary-container clearfix">
  <div class="post-projects clearfix">
    <div class="container clearfix">
      <div class="row clearfix">
        <div class="col-sm-12">        
        
              
             
              <div class="col-sm-12">
                 <label>Name</label>
                  <input type="text" name="name" id="name" required="required" />
                  <div class="field-error-tips" style="display: none;color:red;" id="name_error"></div>
              </div>
             <div class="clearfix"></div> 
               <br />

                <div class="col-sm-12"> 
              <label>SKU</label>
              <div class="row clearfix">
                <div class="col-sm-12">                 
                  <input type="text" name="sku"  id="sku" value="">                  
                </div>
              </div>             
               </div>      
               <div class="clearfix"></div> 
               <br />
               <div class="col-sm-12">
              <label>Description</label>
              <textarea name="description" id="description" required="required" placeholder="Describe  here..."></textarea>
              <div class="field-error-tips" style="display: none;color:red;" id="description_error"></div>
              </div>
              <div class="clearfix"></div> 
               <br />
               <div class="col-sm-12"> 
              <label>Price</label>
              <div class="row clearfix">
                <div class="col-sm-12">                 
                  <input type="number" name="price"  id="price" value="">                  
                </div>
              </div>
              <div class="field-error-tips" style="display: none;color:red;" id="price_range"></div>
               </div>             
              <div class="clearfix"></div>              
              <br />

                           
              <div class="col-sm-12"> 
              <label>Image</label>
              <div class="row clearfix">
                <div class="col-sm-12">                 
                  <input type="file" name="img"  id="img" value="">                  
                </div>
              </div>             
               </div>      
               <div class="clearfix"></div> 
               <br />
             
              
              <input type="submit" name="postproduct" value="Submit" class="btn btn-primary" />
              
            
          </div>
          
          
        </div>
      </div>
    </div>
  </div>
</div>

 
 </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
        
      </div>
    </div>
  </div>
  </div>
</div>
 
</div>



</body>
</html>
