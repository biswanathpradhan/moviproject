<?php 

require_once('autoload.php');

if($_REQUEST['prod']){
	require_once('product.php');
}else{
	require_once('home.php');
}