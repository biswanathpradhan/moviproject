<?php require_once('autoload.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Biswanath</title>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/responsive-menu.js"></script>
<script src="js/slick.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/responsive-menu.css" />
<link rel="stylesheet" type="text/css" href="css/slick.css" />
</head>
<body>
  <div class="container clearfix">
    <div class="fixheader clearfix">  
  <div class="dashboard-menubar clearfix">
    <div class="container clearfix">
      <div class="row clearfix">
        <div class="col-sm-12">
          <nav class="navbar navbar-inverse" role="navigation">
            <div class="container-fluid">           
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  <li><a href="index.php">home</a></li>                     
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
  </div>
  <br>  <br>  <br>
    <div class="row clearfix">
    	<h4>Sorry! Payment Cancelled.</h4>

    	  </div>
  </div>
  </body>
</html>
