<?php require_once('autoload.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Biswanath</title>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/responsive-menu.js"></script>
<script src="js/slick.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/responsive-menu.css" />
<link rel="stylesheet" type="text/css" href="css/slick.css" />
</head>
<body>
  <div class="container clearfix">
    <div class="fixheader clearfix">  
  <div class="dashboard-menubar clearfix">
    <div class="container clearfix">
      <div class="row clearfix">
        <div class="col-sm-12">
          <nav class="navbar navbar-inverse" role="navigation">
            <div class="container-fluid">           
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  <li><a href="index.php">home</a></li>                     
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
  </div>
  <br>  <br>  <br>
  <div class="row clearfix">
    <form action="search.php" method="get">
      <input type="text" name="q" value="" style="width: 250px;">
      <input type="submit" name="search" value="Search" class="btn btn-primary">
    </form>
  </div>
    <div class="row clearfix">
       <?php foreach($list as $k){ ?>
          <div class="col-sm-3" style="text-align: center;">
            <a href="<?php echo $k['pcode']; ?>"><img src="admin/upload/<?php echo $k['image']; ?>" style="width: 150px;">
            </a>
            <a href="<?php echo $k['pcode']; ?>"><h4><?php echo $k['pname']; ?></h4></a>
            <a href="<?php echo $k['pcode']; ?>"><h4><?php echo $k['pcode']; ?></h4></a>
            <a href="<?php echo $k['pcode']; ?>"><h4><?php echo currency.$k['price']; ?></h4></a>
            <a href="<?php echo $k['pcode']; ?>" class="btn btn-primary">View Details</a> | <a href="javascript:void(0);" onclick="quickview(<?php echo $k['pid']; ?>);" class="btn">Quick View</a>
          </div>
       <?php } ?>
    </div>
    <br><br>
    <ul class="pagul" style="text-align: center;"><?php echo $ob->pagenumb($con,$limit,$pn); ?></ul>
  </div>



<div id="locl_model" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    <button type="button" class="close" data-dismiss="modal" onclick="hidemodl();">&times;</button>
      <div class="modal-body">
       <div class="row clearfix" id="quckshow">
       

                
          </div>
          <div class="clearfix"></div>       
      </div>
    </div>
  </div>
</div>
<style>
  .pagul li{
      display: inline;
      line-height: 24px;
    }
    
   .pagul a{
background-color: #233887;
    border: 2px solid #b3c1f8;
    color: #fff;
    font-size: 14px;
    font-weight: 700;
    line-height: 35px;
    margin: 0 5px;
    padding: 0;
    text-align: center;
    width: 40px;

   }   
  </style>

  <script>
  	 function quickview(id){
      
      $.ajax({
          type:'post',
              url:'autoload.php',
              dataType:'json', 
              data:{id: id,'quickview':1},
              success:function(result){
                 $("#quckshow").html(result);
                 $("#locl_model").modal("show");
              }
       });
    }

    function hidemodl(){
    	$("#locl_model").modal("hide");
    }
  </script>
</body>
</html>
