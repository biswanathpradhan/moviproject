<?php
session_start();
error_reporting(0);
require_once('admin/class/db.php');
require_once('admin/class/mclass.php');
require_once('admin/class/post.php');


if(isset($_POST['quickview'])){   
    $k=$ob->edit_prod($con,$_POST['id']);
    $htm='<div class="col-sm-6">
                <img src="admin/upload/'.$k['image'].'" style="width: 350px;">
        </div>  
        <div class="col-sm-6">
             <h3>'.$k['pname'].'</h3> 
             <h5>'.$k['pcode'].'</h5>
             <h5>'.currency.$k['price'].'</h5>
        </div>';
   echo json_encode($htm);     
} 


if(isset($_POST['gotopaypal'])){   
    $k=$ob->edit_prod($con,$_POST['id']);
    $url="https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_xclick&business=bishwain.2010@gmail.com&item_name=".$k['pname']."&item_number=".$k['pcode']."&amount=".$k['price']."&no_shipping=1&currency_code=".currency."&notify_url=http://sambalpuri-saree.com/biswa/notify.php&cancel_return=http://sambalpuri-saree.com/biswa/cancel.php&return=http://sambalpuri-saree.com/biswa/return.php";
   echo json_encode($url);     
}  


if(isset($_GET['q'])){  

	$serch=$ob->serach_result($con,$_POST['q']);

}


$limit = 12;    
if (isset($_GET["page_no"])) {  
    $pn  = $_GET["page_no"];  
}else {  
    $pn=1;  
}
   
$start_from = ($pn-1) * $limit; 
$list=$ob->paginationlist($con,$start_from,$limit);




?>